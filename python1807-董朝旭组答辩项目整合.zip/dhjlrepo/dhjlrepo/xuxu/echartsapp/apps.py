from django.apps import AppConfig


class EchartsappConfig(AppConfig):
    name = 'echartsapp'
