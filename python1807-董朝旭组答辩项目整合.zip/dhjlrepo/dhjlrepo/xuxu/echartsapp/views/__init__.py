from echartsapp.views.index import index_view
from echartsapp.views.pyechart import *